# AltSpeakify 🔊
> Are you a visually impaired individual? Does an image you want to view not have alt text? Is the current caption severly lacking detail, or simply just not sufficient? If you answered "Yes" to any of the above questions, then this Chromium extension is for you!

 AltSpeakify uses AI to describe images on a webpage and read them back to the user in a configurable TTS voice.

 ## Configuration
> YOU MUST COMPLETE THE FOLLOWING STEPS FOR THE EXTENSION TO FUNCTION!!!

**1.) Set the Astica API key in the "Settings" page** (https://astica.ai)

**2.) Set the 11Labs API key in the "Settings" page** (https://elevenlabs.io)


 
